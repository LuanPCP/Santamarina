import React from "react";

const App = () => {
  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Bem-vindo ao site Santamarina!</h1>
      <p style={styles.text}>Seu sistema de pedidos online.</p>
    </div>
  );
};

const styles = {
  container: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    height: "100vh",
    textAlign: "center",
    fontFamily: "Arial, sans-serif",
  },
  title: {
    fontSize: "2rem",
    color: "#333",
  },
  text: {
    fontSize: "1.2rem",
    color: "#666",
  },
};

export default App;