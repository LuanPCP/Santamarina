import React from "react";

function App() {
  return (
    <div>
      <h1>Bem-vindo ao site Santamarina!</h1>
      <p>Seu sistema de pedidos online.</p>
    </div>
  );
}

export default App;